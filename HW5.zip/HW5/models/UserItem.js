class UserItem {

    constructor(itemCode, itemName, categoryName, rating, yourItem) {
        this.itemCode = itemCode;
        this.itemName = itemName;
        this.categoryName = categoryName;
        this.rating = rating;
        this.yourItem = yourItem;
    }
    
    /**
     *
     * Getter and Setters
     */
    
    
}
module.exports = UserItem;